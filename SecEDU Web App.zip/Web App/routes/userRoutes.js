const express = require('express');
const router = express.Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');
const config = require('../config/database');

const User = require('../models/userModels');

router.post('/add', (req, res) => {
    console.log(req.body)
    let userNew = new User({
        fullName: req.body.name,
        emailAdd: req.body.email,
        role: req.body.role,
        password: req.body.password,
        score: 0
    });

    User.addUser(userNew, (err, user) => {
        if (err) {
            res.json({
                success: false,
                msg: 'Failed to create New User'
            })
        } else {
            //res.json('success')
            res.redirect('../login');
        }
    });
});

router.post('/authenticate', (req, res) => {
    const name = req.body.name;
    const password = req.body.password;

    User.GetUserByFullName(name, (err, user) => {
        if (err) throw err;
        if (!user) {
            res.redirect('../login');
        } else {
            User.comparePassword(password, user.password, (err, isMatch) => {
                console.log('trying to compage password')
                if (err) throw err;
                if (isMatch == true) {
                    const token = jwt.sign({
                        user: user
                    }, config.secret, {
                        expiresIn: 6000000
                    });
                    console.log("authenticate route token: " + token);
                    res.redirect('../quiz?authenticated=true&name=' + user.fullName);

                } else {
                    res.redirect('../login');
                }
            });
        }

    });

});

//update
router.put('/update/:name', function (req, res) {
    console.log('update route')
    let updatedUser = {
        name: req.params.name,
        score: req.body.score,
    };

    console.log(updatedUser);

    User.updateUser(req.params.name, updatedUser, function (err, user) {
        if (err) throw err;
        res.json(user);
    })
})



module.exports = router;