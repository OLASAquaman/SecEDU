const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

//User Schemea 
const UserSchema = mongoose.Schema({
    fullName: {
        type: String,
        required: true
    },
    emailAdd: {
        type: String,
        required: true
    },
    role: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    score: {
        type: Number
    }
});

const User = module.exports = mongoose.model('User', UserSchema);

//Get user by ID
module.exports.GetUserByID = function (id, callback) {
    User.findById(id, callback);
}

//Get user by FullName
module.exports.GetUserByFullName = function (name, callback) {
    const query = {
        fullName: name
    }
    User.findOne(query, callback);
}

//Get user by Email Address
module.exports.GetUserByEmail = function (email, callback) {
    const query = {
        emailAdd: email
    }
    User.findOne(query, callback);
}

//Add a user
module.exports.addUser = function (newUser, callback) {
    //hash users password and save to db
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt, (err, hash) => {
            if (err) throw err;
            newUser.password = hash;
            newUser.save(callback);
        });
    })
}

//compare hash of stored password and entered password
module.exports.comparePassword = function (password, hash, callback) {
    bcrypt.compare(password, hash, (err, isMatch) => {
        if (err) throw err;
        console.log("Password match " + isMatch);
        callback(null, isMatch);
    });
}

//get all users
module.exports.getAllUsers = function (callback) {
    User.find(callback)
}

//update user
module.exports.updateUser = function (name, newUser, callback) {
    const query = {
        fullName: name
    }


    User.findOneAndUpdate(query, newUser, function (error, result) {
        // In this moment, you recive a result object or error
        if (error) {
            console.log(error)
        } else {
            console.log(result)
        }

        // ... Your code when have result ... //
    });
}

//delete user
module.exports.deleteUser = function (id, callback) {
    User.findByIdAndDelete(id, callback);
}