module.exports = {
    database: 'mongodb://localhost:27017/SecEDU',
    secret: 'asbifas67t6r2438yjifsdkkjsdfu908fffsae'
}