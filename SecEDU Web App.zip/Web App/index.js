var http = require("http");
var fs = require("fs");

const mongoose = require("mongoose");
const config = require("./config/database");
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const session = require("express-session");

//Deprecation Warnings removed from log
mongoose.set("useNewUrlParser", true);
mongoose.set("useFindAndModify", false);
mongoose.set("useCreateIndex", true);
mongoose.set("useUnifiedTopology", true);

mongoose.connect(config.database);

mongoose.connection.on("connected", () => {
    console.log("Successfully Connected to Database: ");
});

mongoose.connection.on("error", (err) => {
    console.log("Unsuccessful Connection to Database: " + err);
});

var app = express();

//Saves a token (using cookies to allow your borswer to carry on)
const user = require("./routes/userRoutes");
app.use(cors());
app.use(bodyParser.json());
app.use(
    bodyParser.urlencoded({
        extended: true,
    })
);

//Any requests made to the API will be directed through the 'users route file'
app.use("/user", user);

app.use(express.static(__dirname + "/public"));
app.set("views", __dirname + "/public/views");
app.engine("html", require("ejs").renderFile);
app.set("view engine", "html");

//This is the random port I have selected to be used by the web server
var port = 6100;

app.get("/", (req, res) => {
    res.json('Invalid Endpoint')
});

app.get("/register", (req, res) => {
    res.render("register.html");
});

app.get("/login", (req, res) => {
    res.render("login.html");
});

app.get("/congrats", (req, res) => {
    res.render("congratScreen.html");
});

app.get("/quiz", (req, res) => {
    if (req.query.authenticated == 'true') {
        res.render('index.html');
        console.log('success');
    } else {
        console.log('failed');
        res.redirect('/login');
    }
});

app.listen(port, function () {
    console.log("Listening on " + port);
});